package com.example.recipe_app.Util;

public class ServerAPI {
    public static final String BASE_URL = "http://192.168.43.215/recipe/";

    public static final String URL_LOGIN =  BASE_URL + "login.php";
    public static final String URL_REGISTER =  BASE_URL + "register.php";
}
